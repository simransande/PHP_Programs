import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fundoo-notes',
  templateUrl: './fundoo-notes.component.html',
  styleUrls: ['./fundoo-notes.component.css']
})
export class FundooNotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
