<?php
$username = "bridgeit";
$password = "bridgeit";

// Create connection
$conn = new PDO('mysqli:host=localhost;dbname=test', $username, $password);
?>