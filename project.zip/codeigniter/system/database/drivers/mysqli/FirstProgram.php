<?php
$db = mysqli_connect('localhost','root','bridgeit') or die('Unable to connect. Check your connection ');
print_r($db);
?>
