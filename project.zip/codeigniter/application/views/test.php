<?php
echo "Hi ".$this->session->userdata('username')." Welcome in bridgelabz ";
?>